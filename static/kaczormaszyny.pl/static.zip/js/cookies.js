// if (window.localStorage.getItem("cookieConsent") == "yes") {
//     const src = "https://maps.googleapis.com/maps/embed?pb=!1m18!1m12!1m3!1d2496.236826579097!2d20.945113499999994!3d51.2699596!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x471845a3118c7471%3A0x8bc74d2267502429!2sKolonia%20Ku%C5%BAnia%2021%2C%2026-502%20Kolonia%20Ku%C5%BAnia!5e0!3m2!1spl!2spl!4v1708101274395!5m2!1spl!2spl";
//     const googleMapsIframe = document.getElementById("google-maps-iframe");
//     googleMapsIframe.setAttribute("src", src);
// } else {
//     const googleMapsIframe = document.getElementById("google-maps-iframe");
//     googleMapsIframe.setAttribute("style", "width:0px;height:0px;display:none");
// }

const renderCaptcha = () => {

}